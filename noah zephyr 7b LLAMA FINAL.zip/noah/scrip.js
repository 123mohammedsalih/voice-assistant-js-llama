const talkButton = document.querySelector('.talk');
const content = document.querySelector('.content');
const responseText = document.getElementById('responseText');
const statusElement = document.getElementById('status');
const textCommandInput = document.getElementById('textCommand');
const submitTextCommand = document.getElementById('submitTextCommand');
const settingsToggle = document.querySelector('.settings-toggle');
const settingsPanel = document.querySelector('.settings-panel');
const apiKeyInput = document.getElementById('apiKey');
const youtubeApiKeyInput = document.getElementById('youtubeApiKey');
const weatherApiKeyInput = document.getElementById('weatherApiKey');
const aiModeSelect = document.getElementById('aiMode');
const saveSettingsBtn = document.getElementById('saveSettings');

// Configuration
let config = {
    hfApiKey: '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',
    youtubeApiKey: 'AIzaSyALNWZWM0OL2aYZJ1dFOkjRP9aZFp2QQac',
    weatherApiKey: '6ee76fa6142616567dedb0e5c08bfa9a',
    aiMode: 'hybrid'
};

// Load saved settings from localStorage
function loadSettings() {
    const savedConfig = localStorage.getItem('noahConfig');
    if (savedConfig) {
        config = JSON.parse(savedConfig);
        apiKeyInput.value = config.hfApiKey;
        youtubeApiKeyInput.value = config.youtubeApiKey;
        weatherApiKeyInput.value = config.weatherApiKey;
        aiModeSelect.value = config.aiMode;
    }
}

// Save settings to localStorage
function saveSettings() {
    config.hfApiKey = apiKeyInput.value.trim();
    config.youtubeApiKey = youtubeApiKeyInput.value.trim();
    config.weatherApiKey = weatherApiKeyInput.value.trim();
    config.aiMode = aiModeSelect.value;
    localStorage.setItem('noahConfig', JSON.stringify(config));
    settingsPanel.style.display = 'none';
    responseText.textContent = 'Settings saved successfully!';
    speak('Settings saved successfully!');
}

// Query Zephyr-7B via Hugging Face Inference API
async function queryZephyr(prompt) {
    if (!config.hfApiKey) {
        return "Please set your Hugging Face API key in settings";
    }
    
    try {
        statusElement.textContent = "Thinking...";
        
        const response = await fetch(
            "https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta",
            {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${config.hfApiKey}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    inputs: `<|system|>
You are NOAH, a helpful AI assistant. Respond concisely and conversationally.</s>
<|user|>
${prompt}</s>
<|assistant|>`,
                    parameters: {
                        max_new_tokens: 150,
                        temperature: 0.7,
                        repetition_penalty: 1.1
                    }
                })
            }
        );
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        const data = await response.json();
        return data[0].generated_text.split("<|assistant|>")[1].trim();
    } catch (error) {
        console.error("Zephyr API error:", error);
        return "I'm having trouble connecting to the AI. Please check your API key and try again.";
    }
}

// Search YouTube videos
async function searchYouTube(query) {
    if (!config.youtubeApiKey) {
        return "Please set your YouTube API key in settings";
    }

    try {
        statusElement.textContent = "Searching YouTube...";
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=${encodeURIComponent(query)}&key=${config.youtubeApiKey}&type=video`
        );
        
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            const videoId = data.items[0].id.videoId;
            const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
            window.open(videoUrl, '_blank');
            return `Playing: ${data.items[0].snippet.title}`;
        } else {
            return "No videos found for that search";
        }
    } catch (error) {
        console.error("YouTube API error:", error);
        return "Failed to search YouTube. Please check your API key or try again later.";
    }
}

// Get current weather data
async function getCurrentWeather(location) {
    if (!config.weatherApiKey) {
        return "Please set your OpenWeatherMap API key in settings to check weather";
    }

    try {
        statusElement.textContent = "Fetching weather data...";
        
        let apiUrl;
        if (location.toLowerCase() === 'current location' || location.toLowerCase() === 'my location') {
            // Get weather by geolocation
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject);
            });
            apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&units=metric&appid=${config.weatherApiKey}`;
        } else {
            // Get weather by city name
            apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&units=metric&appid=${config.weatherApiKey}`;
        }

        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.cod === 401) {
            throw new Error('Invalid API key');
        }
        if (data.cod === 404) {
            throw new Error('Location not found');
        }
        if (!response.ok) {
            throw new Error('API error');
        }

        // Extract relevant weather data
        const weather = data.weather[0];
        const main = data.main;
        const wind = data.wind;
        const sys = data.sys;
        
        // Format the weather response
        const weatherDescription = weather.description.charAt(0).toUpperCase() + weather.description.slice(1);
        const temp = Math.round(main.temp);
        const feelsLike = Math.round(main.feels_like);
        const humidity = main.humidity;
        const windSpeed = wind.speed;
        
        // Create weather icon URL
        const iconUrl = `https://openweathermap.org/img/wn/${weather.icon}@2x.png`;
        
        // Format HTML response
        responseText.innerHTML = `
            <div class="weather-response">
                <div class="weather-header">
                    <img src="${iconUrl}" alt="${weather.description}">
                    <div>
                        <h3>${data.name}, ${sys.country}</h3>
                        <p class="weather-desc">${weatherDescription}</p>
                    </div>
                </div>
                <div class="weather-details">
                    <p><i class="fas fa-temperature-high"></i> Temperature: ${temp}°C (Feels like ${feelsLike}°C)</p>
                    <p><i class="fas fa-tint"></i> Humidity: ${humidity}%</p>
                    <p><i class="fas fa-wind"></i> Wind: ${windSpeed} m/s</p>
                    <p><i class="fas fa-cloud"></i> Cloudiness: ${data.clouds.all}%</p>
                </div>
            </div>
        `;
        
        // Format spoken response
        return `Current weather in ${data.name}: ${weatherDescription}. Temperature is ${temp} degrees Celsius, feels like ${feelsLike}. Humidity is at ${humidity} percent with wind speed of ${windSpeed} meters per second.`;
        
    } catch (error) {
        console.error("Weather API error:", error);
        let errorMessage = "Sorry, I couldn't retrieve the weather information.";
        
        if (error.message === 'Invalid API key') {
            errorMessage = "Please check your OpenWeatherMap API key in settings.";
        } else if (error.message === 'Location not found') {
            errorMessage = "I couldn't find that location. Please try another city name.";
        } else if (error.message === 'Geolocation error') {
            errorMessage = "I couldn't access your current location. Please enable location permissions or specify a city name.";
        }
        
        return errorMessage;
    }
}


// Check if speech recognition is supported
function checkSpeechSupport() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        talkButton.disabled = true;
        content.textContent = "Speech recognition not supported";
        responseText.textContent = "Please use Chrome, Edge or Safari for voice commands";
        return false;
    }
    return true;
}

// Initialize speech recognition
function initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    recognition.onstart = () => {
        talkButton.classList.add('listening');
        content.textContent = "Listening... Speak now";
        responseText.textContent = "Processing your request...";
        statusElement.textContent = "Microphone is active";
    };
    
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        content.textContent = `You said: "${transcript}"`;
        statusElement.textContent = "Processing your command...";
        processCommand(transcript.toLowerCase());
    };
    
    recognition.onerror = (event) => {
        handleRecognitionError(event.error);
    };
    
    recognition.onend = () => {
        talkButton.classList.remove('listening');
        statusElement.textContent = "Ready for next command";
    };
    
    return recognition;
}

// Handle speech recognition errors
function handleRecognitionError(error) {
    const errors = {
        'no-speech': "No speech detected. Please try again.",
        'audio-capture': "No microphone found. Please check your audio settings.",
        'not-allowed': "Microphone access was denied. Please enable permissions."
    };
    responseText.textContent = errors[error] || "Error occurred in voice recognition";
}


// Process user commands
async function processCommand(command) {
    let response;
    
    // Define command patterns and responses
    const commands = {
        greetings: {
            patterns: ['hello', 'hi', 'hey'],
            response: "Hello there! I'm NOAH, your virtual assistant. How can I help you today?"
        },
        identity: {
            patterns: ['your name', 'who are you'],
            response: "I'm NOAH, your intelligent virtual assistant created to make your life easier!"
        },
        time: {
            patterns: ['time', 'current time'],
            response: `The current time is ${new Date().toLocaleTimeString()}.`
        },
        date: {
            patterns: ['date', 'today\'s date'],
            response: `Today is ${new Date().toLocaleDateString()}.`
        },
        thanks: {
            patterns: ['thank you', 'thanks'],
            response: "You're welcome! Is there anything else I can help with?"
        },
        joke: {
            patterns: ['joke', 'tell me a joke'],
            response: "Why don't scientists trust atoms? Because they make up everything!"
        },
        weather: {
            patterns: ['weather', 'temperature', 'forecast', 'how hot', 'how cold'],
            response: async (command) => {
                const locationMatch = command.match(/weather in (.+)|temperature in (.+)/i);
                const location = (locationMatch && (locationMatch[1] || locationMatch[2])) || 'current location';
                return await getWeatherData(location);
            }
        },
        youtube: {
            patterns: ['play', 'youtube', 'search youtube', 'watch video'],
            response: async (command) => {
                const query = command.match(/play (.+)|search (.+) on youtube|youtube (.+)/i)?.[1] || "";
                if (query) {
                    return await searchYouTube(query);
                }
                window.open('https://www.youtube.com', '_blank');
                return "Opening YouTube...";
            }
        },
        google: {
            patterns: ['google', 'search for'],
            response: (command) => {
                const query = command.match(/google (.+)|search for (.+)/i)?.[1] || "";
                if (query) {
                    window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
                    return `Searching Google for ${query}...`;
                }
                window.open('https://www.google.com', '_blank');
                return "Opening Google...";
            }
        }
    };
    
    // Handle AI mode
    if (config.aiMode === 'ai') {
        response = await queryZephyr(command);
        responseText.textContent = response;
        speak(response);
        return;
    }
    
    // Hybrid mode - try commands first, then fall back to AI
    let matched = false;
    if (config.aiMode !== 'commands') {
        for (const [key, cmd] of Object.entries(commands)) {
            if (cmd.patterns.some(pattern => command.includes(pattern))) {
                if (typeof cmd.response === 'function') {
                    response = await cmd.response(command);
                } else {
                    response = cmd.response;
                }
                matched = true;
                break;
            }
        }
    }
    
    // If no command matched and we're in hybrid mode, or if we're in commands-only mode and no command matched
    if ((!matched && config.aiMode === 'hybrid') || (config.aiMode === 'commands' && !matched)) {
        response = await queryZephyr(command);
    }
    
    if (typeof response === 'string') {
        responseText.textContent = response;
    }
    speak(response);
}

// Text-to-speech function
function speak(text) {
    if (typeof text !== 'string') return;
    
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        const voices = window.speechSynthesis.getVoices();
        const preferredVoices = ['Microsoft Zira', 'Google UK English Female', 'Samantha'];
        const selectedVoice = voices.find(v => preferredVoices.includes(v.name)) || 
                            voices.find(v => v.lang.includes('en'));
        
        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
        
        window.speechSynthesis.speak(utterance);
    } else {
        responseText.textContent += "\n\n(Text-to-speech not supported in your browser)";
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    
    if (checkSpeechSupport()) {
        const recognition = initSpeechRecognition();
        
        talkButton.addEventListener('click', () => {
            if (!talkButton.classList.contains('listening')) {
                recognition.start();
            }
        });
        
        submitTextCommand.addEventListener('click', () => {
            const command = textCommandInput.value.trim();
            if (command) {
                content.textContent = `You typed: "${command}"`;
                statusElement.textContent = "Processing your command...";
                processCommand(command.toLowerCase());
                textCommandInput.value = '';
            }
        });
        
        textCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                submitTextCommand.click();
            }
        });
        
        settingsToggle.addEventListener('click', () => {
            settingsPanel.style.display = settingsPanel.style.display === 'block' ? 'none' : 'block';
        });
        
        saveSettingsBtn.addEventListener('click', saveSettings);
        
        if ('speechSynthesis' in window) {
            window.speechSynthesis.onvoiceschanged = () => {};
        }
    }
});