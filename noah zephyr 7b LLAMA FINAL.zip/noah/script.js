const talkButton = document.querySelector('.talk');
const content = document.querySelector('.content');
const responseText = document.getElementById('responseText');
const statusElement = document.getElementById('status');
const textCommandInput = document.getElementById('textCommand');
const submitTextCommand = document.getElementById('submitTextCommand');
const settingsToggle = document.querySelector('.settings-toggle');
const settingsPanel = document.querySelector('.settings-panel');
const apiKeyInput = document.getElementById('apiKey');
const youtubeApiKeyInput = document.getElementById('youtubeApiKey');
const weatherApiKeyInput = document.getElementById('weatherApiKey');
const aiModeSelect = document.getElementById('aiMode');
const saveSettingsBtn = document.getElementById('saveSettings');

// Configuration with default API keys
let config = {
    hfApiKey: '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',
    youtubeApiKey: 'AIzaSyALNWZWM0OL2aYZJ1dFOkjRP9aZFp2QQac',
    weatherApiKey: '6ee76fa6142616567dedb0e5c08bfa9a',
    aiMode: 'hybrid'
};

// Load saved settings from localStorage
function loadSettings() {
    const savedConfig = localStorage.getItem('noahConfig');
    if (savedConfig) {
        config = JSON.parse(savedConfig);
        apiKeyInput.value = config.hfApiKey;
        youtubeApiKeyInput.value = config.youtubeApiKey;
        weatherApiKeyInput.value = config.weatherApiKey;
        aiModeSelect.value = config.aiMode;
    } else {
        // Set default values in inputs if no saved config
        apiKeyInput.value = config.hfApiKey;
        youtubeApiKeyInput.value = config.youtubeApiKey;
        weatherApiKeyInput.value = config.weatherApiKey;
        aiModeSelect.value = config.aiMode;
    }
}

// Save settings to localStorage
function saveSettings() {
    config.hfApiKey = apiKeyInput.value.trim();
    config.youtubeApiKey = youtubeApiKeyInput.value.trim();
    config.weatherApiKey = weatherApiKeyInput.value.trim();
    config.aiMode = aiModeSelect.value;
    localStorage.setItem('noahConfig', JSON.stringify(config));
    settingsPanel.style.display = 'none';
    responseText.textContent = 'Settings saved successfully!';
    speak('Settings saved successfully!');
}
//generateVerboseResponse
async function generateVerboseResponse(prompt) {
    try {
        // First get the AI response
        let response = await queryZephyr(prompt);
        
        // Ensure proper sentence structure
        if (!/[.!?]$/.test(response)) {
            response += '.';
        }
        
        // Add conversational markers
        response = addConversationalMarkers(response);
        
        // Balance sentence lengths
        response = balanceSentenceLengths(response);
        
        return response;
    } catch (error) {
        console.error("Response generation error:", error);
        return `I'm having trouble formulating a complete response at the moment. ${error.message}. Please try again or ask me something else.`;
    }
}

function addConversationalMarkers(text) {
    const markers = [
        "Let me explain this in more detail.",
        "Here's what you should know about this.",
        "To give you a complete picture,",
        "There are several important aspects to consider.",
        "This is actually quite interesting because"
    ];
    
    // Don't add if already marked
    if (text.includes(markers[0])) return text;
    
    return `${markers[Math.floor(Math.random() * markers.length)]} ${text}`;
}

function balanceSentenceLengths(text) {
    // Split into sentences
    let sentences = text.match(/[^\.!\?]+[\.!\?]+/g) || [text];
    
    // Ensure no sentence is too long
    sentences = sentences.map(sentence => {
        if (sentence.length > 150) {
            // Split long sentences at natural breaks
            const parts = sentence.split(/,|;/);
            if (parts.length > 1) {
                return parts.join('. ').replace(/\.\./g, '.');
            }
        }
        return sentence;
    });
    
    return sentences.join(' ');
}
// Configuration with verbose response settings
const responseSettings = {
    minWords: 80,      // Minimum words for voice responses
    maxWords: 500,     // Maximum words for voice responses
    detailLevel: 'high' // Can be 'low', 'medium', 'high'
};

// Query Zephyr-7B via Hugging Face Inference API
async function queryZephyr(prompt) {
    if (!config.hfApiKey) {
        return "Please set your Hugging Face API key in settings";
    }
    
    try {
        statusElement.textContent = "Thinking...";
        
        const response = await fetch(
            "https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta",
            {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${config.hfApiKey}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    inputs: `<|system|>
You are NOAH, a helpful AI assistant. Respond concisely and conversationally.</s>
<|user|>
${prompt}</s>
<|assistant|>`,
                    parameters: {
                        max_new_tokens: 500, // Increased for more verbose responses
                        temperature: 0.75,
                        repetition_penalty: 1.15,
                        top_k: 50 ,
                        top_p: 0.9
                    }
                })
            }
        );
        
        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }
        
        const data = await response.json();
        let responseText = data[0].generated_text.split("<|assistant|>")[1].trim();
        
        // Add follow-up question if response doesn't end with punctuation
        if (!/[.!?]$/.test(responseText)) {
            responseText += " Is there anything else you'd like to know?";
        }
        
        return responseText;
    } catch (error) {
        console.error("Zephyr API error:", error);
        return "I'm having trouble connecting to the AI. Please check your API key and try again.";
    }
}


// Search YouTube videos
async function searchYouTube(query) {
    if (!config.youtubeApiKey) {
        return "Please set your YouTube API key in settings";
    }

    try {
        statusElement.textContent = "Searching YouTube...";
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=${encodeURIComponent(query)}&key=${config.youtubeApiKey}&type=video`
        );
        
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            const videoId = data.items[0].id.videoId;
            const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
            window.open(videoUrl, '_blank');
            return `Playing: ${data.items[0].snippet.title}. I've opened this in a new tab for you. Would you like to search for something else?`;
        } else {
            return "I couldn't find any videos matching your search. Please try a different query or be more specific about what you're looking for.";
        }
    } catch (error) {
        console.error("YouTube API error:", error);
        return "Failed to search YouTube. Please check your API key or try again later. You can also try visiting YouTube directly.";
    }
}


// Get current weather data with proper location handling
async function getCurrentWeather(location) {
    if (!config.weatherApiKey) {
        return "Please set your OpenWeatherMap API key in settings to check weather";
    }

    try {
        statusElement.textContent = "Fetching weather data...";
        
        let apiUrl;
        let locationName;
        
        // Handle different location types
        if (location.toLowerCase().includes('current') || 
            location.toLowerCase().includes('my location') || 
            location.toLowerCase().includes('here')) {
            
            // Check if geolocation is available
            if (!navigator.geolocation) {
                return "Your browser doesn't support geolocation. Please specify a city name instead (e.g., 'weather in London').";
            }

            // Get weather by geolocation
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(
                    resolve, 
                    (error) => {
                        let errorMessage = "Couldn't access your location. ";
                        switch(error.code) {
                            case error.PERMISSION_DENIED:
                                errorMessage += "Please enable location permissions in your browser settings.";
                                break;
                            case error.POSITION_UNAVAILABLE:
                                errorMessage += "Location information is unavailable. Try specifying a city name.";
                                break;
                            case error.TIMEOUT:
                                errorMessage += "The request to get your location timed out. Please try again.";
                                break;
                            default:
                                errorMessage += "Please specify a city name instead (e.g., 'weather in Mumbai').";
                        }
                        reject(new Error(errorMessage));
                    },
                    {
                        timeout: 10000,
                        enableHighAccuracy: true
                    }
                );
            });
            
            apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&units=metric&appid=${config.weatherApiKey}`;
            locationName = 'your current location';
        } else {
            // Get weather by city name
            const locationQuery = location.replace(/weather in |temperature in |forecast in |for /gi, '').trim();
            apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(locationQuery)}&units=metric&appid=${config.weatherApiKey}`;
            locationName = locationQuery;
        }

        const response = await fetch(apiUrl);
        const data = await response.json();

        if (data.cod === 401) throw new Error('Invalid API key');
        if (data.cod === 404) throw new Error('Location not found');
        if (!response.ok) throw new Error('API error');

        // Extract and format weather data
        const weather = data.weather[0];
        const main = data.main;
        const wind = data.wind;
        const sys = data.sys;
        
        const weatherDescription = weather.description.charAt(0).toUpperCase() + weather.description.slice(1);
        const temp = Math.round(main.temp);
        const feelsLike = Math.round(main.feels_like);
        const humidity = main.humidity;
        const windSpeed = Math.round(wind.speed * 3.6); // Convert to km/h
        const iconUrl = `https://openweathermap.org/img/wn/${weather.icon}@2x.png`;
        const sunriseTime = new Date(sys.sunrise * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        const sunsetTime = new Date(sys.sunset * 1000).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        // Format HTML response
        responseText.innerHTML = `
            <div class="weather-response">
                <div class="weather-header">
                    <img src="${iconUrl}" alt="${weather.description}">
                    <div>
                        <h3>${data.name}, ${sys.country}</h3>
                        <p class="weather-desc">${weatherDescription}</p>
                    </div>
                </div>
                <div class="weather-details">
                    <p><i class="fas fa-temperature-high"></i> Temperature: ${temp}°C (Feels like ${feelsLike}°C)</p>
                    <p><i class="fas fa-tint"></i> Humidity: ${humidity}%</p>
                    <p><i class="fas fa-wind"></i> Wind: ${windSpeed} km/h</p>
                    <p><i class="fas fa-cloud"></i> Cloudiness: ${data.clouds.all}%</p>
                    <p><i class="fas fa-sun"></i> Sunrise: ${sunriseTime}</p>
                    <p><i class="fas fa-moon"></i> Sunset: ${sunsetTime}</p>
                </div>
            </div>
        `;
        
        return `Here's the weather for ${data.name}, ${sys.country}: ${weatherDescription.toLowerCase()} with ${temp}°C (feels like ${feelsLike}°C). Humidity ${humidity}%, wind ${windSpeed} km/h. Sunrise ${sunriseTime}, sunset ${sunsetTime}. Need forecast for another time?`;
        
    } catch (error) {
        console.error("Weather error:", error);
        return error.message || "Couldn't get weather data. Please try again or specify a city name.";
    }
}

// Check if speech recognition is supported
function checkSpeechSupport() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        talkButton.disabled = true;
        content.textContent = "Speech recognition not supported";
        responseText.textContent = "Please use Chrome, Edge or Safari for voice commands";
        return false;
    }
    return true;
}

// Initialize speech recognition
function initSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    
    recognition.onstart = () => {
        talkButton.classList.add('listening');
        content.textContent = "Listening... Speak now";
        responseText.textContent = "Processing your request...";
        statusElement.textContent = "Microphone is active";
    };
    
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        content.textContent = `You said: "${transcript}"`;
        statusElement.textContent = "Processing your command...";
        processCommand(transcript.toLowerCase());
    };
    
    recognition.onerror = (event) => {
        const errors = {
            'no-speech': "No speech detected. Please try again.",
            'audio-capture': "No microphone found. Please check your audio settings.",
            'not-allowed': "Microphone access was denied. Please enable permissions."
        };
        responseText.textContent = errors[event.error] || "Error occurred in voice recognition";
    };
    
    recognition.onend = () => {
        talkButton.classList.remove('listening');
        statusElement.textContent = "Ready for next command";
    };
    
    return recognition;
}

// Process user commands with verbose responses
async function processCommand(command) {
    let response;
    
    // Define command patterns with verbose responses
    const commands = {
        greetings: {
            patterns: ['hello', 'hi', 'hey', 'greetings'],
            response: "Hello there! I'm NOAH, your intelligent virtual assistant. I'm here to help with anything you need - whether it's answering questions, searching the web, checking the weather, or just having a conversation. What can I do for you today?"
        },
        identity: {
            patterns: ['your name', 'who are you', 'what are you'],
            response: "I'm NOAH, which stands for Networked Omni-functional Assistant Helper. I'm an advanced AI assistant designed to provide comprehensive support across multiple domains. My capabilities include web searching, media playback, weather forecasting, answering questions, and much more. I'm constantly learning and evolving to better serve your needs!"
        },
        time: {
            patterns: ['time', 'current time', 'what time is it'],
            response: () => {
                const now = new Date();
                const options = { hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true };
                const timeString = now.toLocaleTimeString('en-US', options);
                const dayPeriod = now.getHours() < 12 ? "morning" : now.getHours() < 18 ? "afternoon" : "evening";
                
                return `The current time is ${timeString}. It's ${dayPeriod} where you are. Proper time management is essential for productivity, so I'd be happy to help you set reminders, alarms, or schedule events if that would be helpful. Would you like me to assist with any time-related tasks?`;
            }
        },
        date: {
            patterns: ['date', 'today\'s date', 'what day is it'],
            response: () => {
                const now = new Date();
                const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                const dateString = now.toLocaleDateString('en-US', options);
                
                return `Today is ${dateString}. We're currently in ${getSeason(now.getMonth())}, a wonderful time of year. If you need help planning your schedule, tracking important dates, or setting calendar reminders, I'd be delighted to assist with those organizational tasks as well.`;
            }
        },
        thanks: {
            patterns: ['thank you', 'thanks', 'appreciate it'],
            response: "You're most welcome! It's truly my pleasure to assist you. Helping users like yourself is my primary purpose, and I'm always happy to provide support. If there's anything else at all that you need help with, no matter how big or small, please don't hesitate to ask. I'm here to make your life easier and more productive in any way I can."
        },
        joke: {
            patterns: ['joke', 'tell me a joke', 'make me laugh'],
            response: "Why don't scientists trust atoms? Because they make up everything! But here's another one for you: I told my computer I needed a break, and now it won't stop sending me Kit-Kat ads. Computers can be so literal sometimes! Would you like to hear another joke or perhaps learn something interesting instead?"
        },
        weather: {
            patterns: ['weather', 'temperature', 'forecast', 'how hot', 'how cold', 'weather in', 'temperature in'],
            response: async (command) => {
                let location = 'current location';
                
                // Extract location from different command patterns
                if (command.includes('weather in')) {
                    location = command.split('weather in')[1].trim();
                } 
                else if (command.includes('temperature in')) {
                    location = command.split('temperature in')[1].trim();
                }
                else if (command.includes('how hot in')) {
                    location = command.split('how hot in')[1].trim();
                }
                else if (command.includes('how cold in')) {
                    location = command.split('how cold in')[1].trim();
                }
                else if (command.includes('forecast in')) {
                    location = command.split('forecast in')[1].trim();
                }
                
                return await getCurrentWeather(location);
            }
        },
        youtube: {
            patterns: ['play', 'youtube', 'search youtube', 'watch video', 'find video'],
            response: async (command) => {
                const query = command.match(/play (.+)|search (.+) on youtube|youtube (.+)/i)?.[1] || "";
                if (query) {
                    return await searchYouTube(query);
                }
                window.open('https://www.youtube.com', '_blank');
                return "I'm opening YouTube in a new tab for you. YouTube is an excellent platform with a wide variety of content including music, tutorials, documentaries, and much more. Would you like me to search for anything specific while we're at it?";
            }
        },
        google: {
            patterns: ['google', 'search for', 'look up'],
            response: (command) => {
                const query = command.match(/google (.+)|search for (.+)|look up (.+)/i)?.[1] || "";
                if (query) {
                    window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
                    return `I'm searching Google for "${query}" and opening the results in a new tab. Google is a powerful search engine that can help find information on virtually any topic. If you don't find what you're looking for, I can help refine your search terms or try alternative sources.`;
                }
                window.open('https://www.google.com', '_blank');
                return "I'm opening Google's homepage in a new tab for you. From here you can search for anything you need. Would you like me to perform a specific search for you instead?";
            }
        }
    };

    function speak(text) {
        if (typeof text !== 'string' || text.trim() === '') return;
        
        if ('speechSynthesis' in window) {
            // Cancel any ongoing speech
            window.speechSynthesis.cancel();
            
            // Split long text into sentences
            const sentences = text.match(/[^\.!\?]+[\.!\?]+/g) || [text];
            
            // Process each sentence individually
            sentences.forEach((sentence, index) => {
                const utterance = new SpeechSynthesisUtterance(sentence.trim());
                
                // Configure voice settings
                utterance.rate = 0.9; // Slightly slower for clarity
                utterance.pitch = 1.0;
                utterance.volume = 1.0;
                
                // Add slight pause between sentences
                if (index > 0) {
                    utterance.onstart = () => {
                        // Small delay between sentences
                        return new Promise(resolve => setTimeout(resolve, 300));
                    };
                }
                
                // Select the best available voice
                const voices = window.speechSynthesis.getVoices();
                const preferredVoices = [
                    'Microsoft David Desktop',
                    'Google UK English Male',
                    'Microsoft Zira',
                    'Google US English',
                    'Samantha'
                ];
                
                const selectedVoice = voices.find(v => preferredVoices.includes(v.name)) || 
                                    voices.find(v => v.lang.includes('en'));
                
                if (selectedVoice) {
                    utterance.voice = selectedVoice;
                }
                
                // Error handling
                utterance.onerror = (event) => {
                    console.error('SpeechSynthesis error:', event);
                    responseText.textContent += "\n\n(Speech error - displaying full text instead)";
                };
                
                window.speechSynthesis.speak(utterance);
            });
        } else {
            responseText.textContent += "\n\n(Text-to-speech not supported - displaying full text)";
        }
    }

    // Helper function for season detection
    function checkLocationSupport() {
        if (!navigator.geolocation) {
            responseText.innerHTML += `
                <div class="warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>Your browser doesn't support geolocation. For weather, please specify a city name.</span>
                </div>
            `;
            return false;
        }
        return true;
    }
    function getSeason(month) {
        if (month >= 2 && month <= 4) return 'spring';
        if (month >= 5 && month <= 7) return 'summer';
        if (month >= 8 && month <= 10) return 'autumn';
        return 'winter';
    }
    
    // Handle AI mode
    if (config.aiMode === 'ai') {
        response = await queryZephyr(command);
        responseText.textContent = response;
        speak(response);
        return;
    }
    
    // Hybrid mode - try commands first, then fall back to AI
    let matched = false;
    if (config.aiMode !== 'commands') {
        for (const [key, cmd] of Object.entries(commands)) {
            if (cmd.patterns.some(pattern => command.includes(pattern))) {
                if (typeof cmd.response === 'function') {
                    response = await cmd.response(command);
                } else {
                    response = cmd.response;
                }
                matched = true;
                break;
            }
        }
    }
    
    // If no command matched and we're in hybrid mode, or if we're in commands-only mode and no command matched
    if ((!matched && config.aiMode === 'hybrid') || (config.aiMode === 'commands' && !matched)) {
        response = await queryZephyr(command);
    }
    
    if (typeof response === 'string') {
        responseText.textContent = response;
    }
    speak(response);
}

// Text-to-speech function
function speak(text) {
    if (typeof text !== 'string') return;
    
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        const voices = window.speechSynthesis.getVoices();
        const preferredVoices = ['Microsoft Zira', 'Google UK English Female', 'Samantha'];
        const selectedVoice = voices.find(v => preferredVoices.includes(v.name)) || 
                            voices.find(v => v.lang.includes('en'));
        
        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
        
        window.speechSynthesis.speak(utterance);
    } else {
        responseText.textContent += "\n\n(Text-to-speech not supported in your browser)";
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    
    if (checkSpeechSupport()) {
        const recognition = initSpeechRecognition();
        
        if (!navigator.geolocation) {
            responseText.textContent += "\n\nNote: Location services are not supported in your browser. For weather, please specify a city name.";
        }
        
        talkButton.addEventListener('click', () => {
            if (!talkButton.classList.contains('listening')) {
                recognition.start();
            }
        });
        
        submitTextCommand.addEventListener('click', () => {
            const command = textCommandInput.value.trim();
            if (command) {
                content.textContent = `You typed: "${command}"`;
                statusElement.textContent = "Processing your command...";
                processCommand(command.toLowerCase());
                textCommandInput.value = '';
            }
        });
        
        textCommandInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                submitTextCommand.click();
            }
        });
        
        settingsToggle.addEventListener('click', () => {
            settingsPanel.style.display = settingsPanel.style.display === 'block' ? 'none' : 'block';
        });
        
        saveSettingsBtn.addEventListener('click', saveSettings);
        
        if ('speechSynthesis' in window) {
            window.speechSynthesis.onvoiceschanged = () => {};
        }
    }
});